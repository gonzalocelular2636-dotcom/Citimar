Edita WhatsApp y correo en index.html y script.js. Abre index.html para ver la web.
